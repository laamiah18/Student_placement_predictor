import { useCallback } from "react";
import { useDropzone } from "react-dropzone";
import { Upload, FileSpreadsheet } from "lucide-react";
import { cn } from "@/lib/utils";

interface FileUploadProps {
  onFileSelect: (file: File) => void;
  accept?: Record<string, string[]>;
  className?: string;
}

export function FileUpload({ onFileSelect, accept, className }: FileUploadProps) {
  const onDrop = useCallback(
    (acceptedFiles: File[]) => {
      if (acceptedFiles.length > 0) {
        onFileSelect(acceptedFiles[0]);
      }
    },
    [onFileSelect]
  );

  const { getRootProps, getInputProps, isDragActive, acceptedFiles } = useDropzone({
    onDrop,
    accept: accept || {
      "text/csv": [".csv"],
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": [".xlsx"],
      "application/vnd.ms-excel": [".xls"],
    },
    maxFiles: 1,
  });

  return (
    <div
      {...getRootProps()}
      className={cn(
        "border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all duration-300",
        isDragActive
          ? "border-primary bg-primary/10"
          : "border-border hover:border-primary/50 hover:bg-card",
        className
      )}
    >
      <input {...getInputProps()} />
      <div className="flex flex-col items-center gap-4">
        {acceptedFiles.length > 0 ? (
          <>
            <FileSpreadsheet className="h-12 w-12 text-primary" />
            <div>
              <p className="text-foreground font-medium">{acceptedFiles[0].name}</p>
              <p className="text-sm text-muted-foreground">
                {(acceptedFiles[0].size / 1024).toFixed(1)} KB
              </p>
            </div>
          </>
        ) : (
          <>
            <div className="relative">
              <div className="absolute inset-0 bg-primary/20 blur-xl rounded-full" />
              <Upload className="h-12 w-12 text-primary relative z-10" />
            </div>
            <div>
              <p className="text-foreground font-medium">
                {isDragActive ? "Drop the file here" : "Drag & drop your file here"}
              </p>
              <p className="text-sm text-muted-foreground mt-1">
                or click to browse (CSV, Excel)
              </p>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
