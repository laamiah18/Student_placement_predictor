import { useLocation, useNavigate, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Header } from "@/components/Header";
import { CircularProgress } from "@/components/CircularProgress";
import { 
  CheckCircle2, 
  XCircle, 
  Briefcase, 
  ArrowLeft, 
  Lightbulb,
  Code,
  Database,
  Globe,
  TestTube,
  Smartphone,
  Shield,
  BarChart3
} from "lucide-react";
import { StudentFormData } from "./StudentMode";
import { useEffect, useState } from "react";

interface JobRole {
  name: string;
  icon: React.ReactNode;
  eligible: boolean;
  score: number;
}

const StudentResults = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const formData = location.state?.formData as StudentFormData | undefined;

  const [placementProbability, setPlacementProbability] = useState(0);
  const [willBePlaced, setWillBePlaced] = useState(false);
  const [jobRoles, setJobRoles] = useState<JobRole[]>([]);

  useEffect(() => {
    if (!formData) {
      navigate("/student");
      return;
    }

    // Calculate placement probability based on form data
    const cgpaWeight = 0.25;
    const internshipWeight = 0.15;
    const projectWeight = 0.15;
    const certWeight = 0.1;
    const aptitudeWeight = 0.15;
    const commWeight = 0.1;
    const techWeight = 0.1;

    const normalizedCgpa = (formData.cgpa / 10) * 100;
    const normalizedInternships = Math.min(formData.internships / 3, 1) * 100;
    const normalizedProjects = Math.min(formData.projects / 5, 1) * 100;
    const normalizedCerts = Math.min(formData.certifications / 3, 1) * 100;
    const normalizedAptitude = formData.aptitudeScore;
    const normalizedComm = formData.communicationSkills * 10;
    const normalizedTech = formData.technicalSkills * 10;

    const probability = Math.round(
      normalizedCgpa * cgpaWeight +
      normalizedInternships * internshipWeight +
      normalizedProjects * projectWeight +
      normalizedCerts * certWeight +
      normalizedAptitude * aptitudeWeight +
      normalizedComm * commWeight +
      normalizedTech * techWeight
    );

    setPlacementProbability(Math.min(probability, 99));
    setWillBePlaced(probability >= 60);

    // Calculate job role eligibility
    const roles: JobRole[] = [
      {
        name: "Software Developer",
        icon: <Code className="h-5 w-5" />,
        eligible: formData.technicalSkills >= 7 && formData.cgpa >= 7,
        score: (formData.technicalSkills * 10 + normalizedCgpa) / 2,
      },
      {
        name: "Data Analyst",
        icon: <Database className="h-5 w-5" />,
        eligible: formData.aptitudeScore >= 70 && formData.technicalSkills >= 6,
        score: (formData.aptitudeScore + formData.technicalSkills * 10) / 2,
      },
      {
        name: "Web Developer",
        icon: <Globe className="h-5 w-5" />,
        eligible: formData.technicalSkills >= 6 && formData.projects >= 2,
        score: (formData.technicalSkills * 10 + normalizedProjects) / 2,
      },
      {
        name: "QA Engineer",
        icon: <TestTube className="h-5 w-5" />,
        eligible: formData.aptitudeScore >= 60 && formData.cgpa >= 6,
        score: (formData.aptitudeScore + normalizedCgpa) / 2,
      },
      {
        name: "Mobile Developer",
        icon: <Smartphone className="h-5 w-5" />,
        eligible: formData.technicalSkills >= 7 && formData.projects >= 3,
        score: (formData.technicalSkills * 10 + normalizedProjects) / 2,
      },
      {
        name: "Security Analyst",
        icon: <Shield className="h-5 w-5" />,
        eligible: formData.technicalSkills >= 8 && formData.aptitudeScore >= 75,
        score: (formData.technicalSkills * 10 + formData.aptitudeScore) / 2,
      },
      {
        name: "Business Analyst",
        icon: <BarChart3 className="h-5 w-5" />,
        eligible: formData.communicationSkills >= 7 && formData.aptitudeScore >= 70,
        score: (formData.communicationSkills * 10 + formData.aptitudeScore) / 2,
      },
    ];

    setJobRoles(roles.sort((a, b) => b.score - a.score));
  }, [formData, navigate]);

  if (!formData) {
    return null;
  }

  const recommendations = [];
  if (formData.technicalSkills < 7) {
    recommendations.push("Improve technical skills through online courses and practice");
  }
  if (formData.communicationSkills < 7) {
    recommendations.push("Work on communication through presentations and group discussions");
  }
  if (formData.internships < 2) {
    recommendations.push("Gain more industry experience through internships");
  }
  if (formData.projects < 3) {
    recommendations.push("Build more projects to showcase your skills");
  }
  if (formData.certifications < 2) {
    recommendations.push("Get certified in relevant technologies");
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="pt-24 pb-12 px-4">
        <div className="max-w-5xl mx-auto">
          <div className="mb-8">
            <Button variant="ghost" onClick={() => navigate("/student")} className="mb-4">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Form
            </Button>
            <h1 className="text-4xl font-bold mb-3">
              Your <span className="text-gradient-gold">Results</span>
            </h1>
            <p className="text-muted-foreground">
              Based on your profile analysis, here are your placement predictions
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-6 mb-8">
            {/* Placement Status Card */}
            <Card variant="gold" className="overflow-hidden">
              <div className={`h-2 ${willBePlaced ? "bg-success" : "bg-destructive"}`} />
              <CardHeader className="text-center pb-2">
                <CardTitle className="text-lg">Placement Status</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <div className={`inline-flex items-center justify-center w-20 h-20 rounded-full mb-4 ${
                  willBePlaced ? "bg-success/20" : "bg-destructive/20"
                }`}>
                  {willBePlaced ? (
                    <CheckCircle2 className="h-10 w-10 text-success" />
                  ) : (
                    <XCircle className="h-10 w-10 text-destructive" />
                  )}
                </div>
                <h3 className={`text-2xl font-bold ${willBePlaced ? "text-success" : "text-destructive"}`}>
                  {willBePlaced ? "Will Be Placed" : "Needs Improvement"}
                </h3>
                <p className="text-sm text-muted-foreground mt-2">
                  {willBePlaced 
                    ? "Your profile shows strong placement potential" 
                    : "Focus on improving key areas"}
                </p>
              </CardContent>
            </Card>

            {/* Probability Card */}
            <Card variant="gold" className="overflow-hidden">
              <div className="h-2 bg-gradient-to-r from-gold-light via-gold to-gold-dark" />
              <CardHeader className="text-center pb-2">
                <CardTitle className="text-lg">Placement Probability</CardTitle>
              </CardHeader>
              <CardContent className="flex flex-col items-center">
                <CircularProgress percentage={placementProbability} />
                <p className="text-sm text-muted-foreground mt-4">
                  Based on your profile metrics
                </p>
              </CardContent>
            </Card>

            {/* Quick Stats Card */}
            <Card variant="gold" className="overflow-hidden">
              <div className="h-2 bg-gradient-to-r from-gold-dark via-gold to-gold-light" />
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Profile Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">CGPA</span>
                  <span className="font-semibold">{formData.cgpa.toFixed(1)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Internships</span>
                  <span className="font-semibold">{formData.internships}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Projects</span>
                  <span className="font-semibold">{formData.projects}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Technical Skills</span>
                  <span className="font-semibold">{formData.technicalSkills}/10</span>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Job Roles */}
          <Card variant="default" className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Briefcase className="h-5 w-5 text-primary" />
                Suitable Job Roles
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {jobRoles.map((role, index) => (
                  <div
                    key={index}
                    className={`p-4 rounded-lg border transition-all duration-200 ${
                      role.eligible
                        ? "border-success/30 bg-success/5 hover:border-success/50"
                        : "border-warning/30 bg-warning/5 hover:border-warning/50"
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`p-2 rounded-lg ${
                        role.eligible ? "bg-success/20 text-success" : "bg-warning/20 text-warning"
                      }`}>
                        {role.icon}
                      </div>
                      <div>
                        <h4 className="font-medium">{role.name}</h4>
                        <span className={`text-xs font-medium ${
                          role.eligible ? "text-success" : "text-warning"
                        }`}>
                          {role.eligible ? "✓ Eligible" : "⚠ Needs Improvement"}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Recommendations */}
          {recommendations.length > 0 && (
            <Card variant="gold">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Lightbulb className="h-5 w-5 text-primary" />
                  Recommendations
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {recommendations.map((rec, index) => (
                    <li key={index} className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <span className="text-xs font-bold text-primary">{index + 1}</span>
                      </div>
                      <span className="text-foreground">{rec}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          )}

          <div className="mt-8 text-center">
            <Button variant="gold" size="lg" asChild>
              <Link to="/student">
                Analyze Again
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudentResults;
