import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Header } from "@/components/Header";
import { GraduationCap, Briefcase, FolderGit2, Award, Brain, MessageSquare, Code, RotateCcw, Sparkles } from "lucide-react";

export interface StudentFormData {
  cgpa: number;
  internships: number;
  projects: number;
  certifications: number;
  aptitudeScore: number;
  communicationSkills: number;
  technicalSkills: number;
}

const StudentMode = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState<StudentFormData>({
    cgpa: 7.0,
    internships: 1,
    projects: 2,
    certifications: 1,
    aptitudeScore: 70,
    communicationSkills: 7,
    technicalSkills: 7,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Navigate to results with form data
    navigate("/student/results", { state: { formData } });
  };

  const handleReset = () => {
    setFormData({
      cgpa: 7.0,
      internships: 1,
      projects: 2,
      certifications: 1,
      aptitudeScore: 70,
      communicationSkills: 7,
      technicalSkills: 7,
    });
  };

  const fields = [
    {
      key: "cgpa",
      label: "CGPA",
      icon: <GraduationCap className="h-5 w-5" />,
      type: "number",
      min: 0,
      max: 10,
      step: 0.1,
      description: "Your cumulative grade point average (0-10)",
    },
    {
      key: "internships",
      label: "Internship Experience",
      icon: <Briefcase className="h-5 w-5" />,
      type: "number",
      min: 0,
      max: 10,
      step: 1,
      description: "Number of internships completed",
    },
    {
      key: "projects",
      label: "Number of Projects",
      icon: <FolderGit2 className="h-5 w-5" />,
      type: "number",
      min: 0,
      max: 20,
      step: 1,
      description: "Technical projects you've worked on",
    },
    {
      key: "certifications",
      label: "Certifications Count",
      icon: <Award className="h-5 w-5" />,
      type: "number",
      min: 0,
      max: 20,
      step: 1,
      description: "Professional certifications earned",
    },
    {
      key: "aptitudeScore",
      label: "Aptitude Test Score",
      icon: <Brain className="h-5 w-5" />,
      type: "number",
      min: 0,
      max: 100,
      step: 1,
      description: "Your aptitude test score (0-100)",
    },
  ];

  const sliderFields = [
    {
      key: "communicationSkills",
      label: "Communication Skills",
      icon: <MessageSquare className="h-5 w-5" />,
      description: "Rate your communication abilities",
    },
    {
      key: "technicalSkills",
      label: "Technical Skills",
      icon: <Code className="h-5 w-5" />,
      description: "Rate your technical proficiency",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="pt-24 pb-12 px-4">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-4">
              <GraduationCap className="h-4 w-4 text-primary" />
              <span className="text-sm text-primary font-medium">Student Mode</span>
            </div>
            <h1 className="text-4xl font-bold mb-3">
              Enter Your <span className="text-gradient-gold">Profile</span>
            </h1>
            <p className="text-muted-foreground max-w-xl mx-auto">
              Fill in your academic and professional details to get personalized placement predictions
            </p>
          </div>

          <Card variant="gold" className="overflow-hidden">
            <div className="h-1 bg-gradient-to-r from-gold-light via-gold to-gold-dark" />
            <CardHeader>
              <CardTitle>Student Profile Form</CardTitle>
              <CardDescription>
                All fields are required for accurate predictions
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Number inputs */}
                <div className="grid md:grid-cols-2 gap-6">
                  {fields.map((field) => (
                    <div key={field.key} className="space-y-2">
                      <Label htmlFor={field.key} className="flex items-center gap-2">
                        <span className="text-primary">{field.icon}</span>
                        {field.label}
                      </Label>
                      <Input
                        id={field.key}
                        type="number"
                        min={field.min}
                        max={field.max}
                        step={field.step}
                        value={formData[field.key as keyof StudentFormData]}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            [field.key]: parseFloat(e.target.value) || 0,
                          })
                        }
                      />
                      <p className="text-xs text-muted-foreground">{field.description}</p>
                    </div>
                  ))}
                </div>

                {/* Slider inputs */}
                <div className="space-y-8 pt-4">
                  {sliderFields.map((field) => (
                    <div key={field.key} className="space-y-4">
                      <div className="flex items-center justify-between">
                        <Label className="flex items-center gap-2">
                          <span className="text-primary">{field.icon}</span>
                          {field.label}
                        </Label>
                        <span className="text-2xl font-bold text-gradient-gold">
                          {formData[field.key as keyof StudentFormData]}/10
                        </span>
                      </div>
                      <Slider
                        value={[formData[field.key as keyof StudentFormData]]}
                        onValueChange={(value) =>
                          setFormData({
                            ...formData,
                            [field.key]: value[0],
                          })
                        }
                        max={10}
                        min={1}
                        step={1}
                      />
                      <p className="text-xs text-muted-foreground">{field.description}</p>
                    </div>
                  ))}
                </div>

                {/* Buttons */}
                <div className="flex gap-4 pt-6">
                  <Button type="submit" variant="gold" className="flex-1">
                    <Sparkles className="h-4 w-4 mr-2" />
                    Predict Placement
                  </Button>
                  <Button type="button" variant="outline" onClick={handleReset}>
                    <RotateCcw className="h-4 w-4 mr-2" />
                    Reset
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default StudentMode;
