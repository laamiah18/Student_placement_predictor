import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Header } from "@/components/Header";
import { FileUpload } from "@/components/FileUpload";
import { Users, FileSpreadsheet, ArrowRight, Info } from "lucide-react";

const TeacherMode = () => {
  const navigate = useNavigate();
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  const handleFileSelect = (file: File) => {
    setSelectedFile(file);
  };

  const handleAnalyze = () => {
    if (selectedFile) {
      // In a real app, we would parse the file here
      // For demo, we'll navigate with mock data
      navigate("/teacher/dashboard", { state: { fileName: selectedFile.name } });
    }
  };

  const requiredColumns = [
    "Student Name",
    "CGPA",
    "Internships",
    "Projects",
    "Certifications",
    "Aptitude Score",
    "Communication Skills (1-10)",
    "Technical Skills (1-10)",
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="pt-24 pb-12 px-4">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-4">
              <Users className="h-4 w-4 text-primary" />
              <span className="text-sm text-primary font-medium">Teacher / Trainer Mode</span>
            </div>
            <h1 className="text-4xl font-bold mb-3">
              Bulk <span className="text-gradient-gold">Analysis</span>
            </h1>
            <p className="text-muted-foreground max-w-xl mx-auto">
              Upload your student data file to analyze placement readiness for the entire batch
            </p>
          </div>

          <Card variant="gold" className="overflow-hidden mb-8">
            <div className="h-1 bg-gradient-to-r from-gold-light via-gold to-gold-dark" />
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileSpreadsheet className="h-5 w-5 text-primary" />
                Upload Student Data
              </CardTitle>
              <CardDescription>
                Upload a CSV or Excel file containing student information
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <FileUpload onFileSelect={handleFileSelect} />

              <Button 
                variant="gold" 
                className="w-full" 
                disabled={!selectedFile}
                onClick={handleAnalyze}
              >
                Run Placement Analysis
                <ArrowRight className="h-4 w-4 ml-2" />
              </Button>
            </CardContent>
          </Card>

          <Card variant="default">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Info className="h-5 w-5 text-primary" />
                Required Columns
              </CardTitle>
              <CardDescription>
                Your file should contain the following columns
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid sm:grid-cols-2 gap-3">
                {requiredColumns.map((column, index) => (
                  <div
                    key={index}
                    className="flex items-center gap-2 p-3 rounded-lg bg-secondary/50 border border-border"
                  >
                    <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                      <span className="text-xs font-bold text-primary">{index + 1}</span>
                    </div>
                    <span className="text-sm">{column}</span>
                  </div>
                ))}
              </div>
              <p className="text-sm text-muted-foreground mt-4">
                Download our <button className="text-primary hover:underline">sample template</button> to get started quickly.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default TeacherMode;
