import { useLocation, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Header } from "@/components/Header";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { 
  ArrowLeft, 
  Users, 
  TrendingUp, 
  CheckCircle2, 
  XCircle,
  Download,
  BarChart3,
  AlertTriangle
} from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";

interface StudentData {
  name: string;
  cgpa: number;
  status: "placed" | "not_placed";
  probability: number;
  topRole: string;
}

const TeacherDashboard = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const fileName = location.state?.fileName;

  // Mock data for demonstration
  const mockStudents: StudentData[] = [
    { name: "Rahul Sharma", cgpa: 8.5, status: "placed", probability: 85, topRole: "Software Developer" },
    { name: "Priya Patel", cgpa: 7.8, status: "placed", probability: 72, topRole: "Data Analyst" },
    { name: "Amit Kumar", cgpa: 6.2, status: "not_placed", probability: 45, topRole: "QA Engineer" },
    { name: "Sneha Reddy", cgpa: 9.1, status: "placed", probability: 92, topRole: "Software Developer" },
    { name: "Vikram Singh", cgpa: 7.0, status: "placed", probability: 65, topRole: "Web Developer" },
    { name: "Ananya Gupta", cgpa: 5.8, status: "not_placed", probability: 38, topRole: "Technical Support" },
    { name: "Rohan Joshi", cgpa: 8.2, status: "placed", probability: 78, topRole: "Mobile Developer" },
    { name: "Kavita Nair", cgpa: 6.5, status: "not_placed", probability: 52, topRole: "Business Analyst" },
    { name: "Arjun Mehta", cgpa: 7.5, status: "placed", probability: 68, topRole: "Software Developer" },
    { name: "Divya Iyer", cgpa: 8.8, status: "placed", probability: 88, topRole: "Data Analyst" },
  ];

  const totalStudents = mockStudents.length;
  const placedStudents = mockStudents.filter(s => s.status === "placed").length;
  const placedPercentage = Math.round((placedStudents / totalStudents) * 100);
  const averageProbability = Math.round(mockStudents.reduce((acc, s) => acc + s.probability, 0) / totalStudents);

  const chartData = [
    { name: "Placed", value: placedStudents, color: "hsl(142, 76%, 45%)" },
    { name: "Not Placed", value: totalStudents - placedStudents, color: "hsl(0, 84%, 60%)" },
  ];

  const skillGaps = [
    { skill: "Technical Skills", students: 4, severity: "high" },
    { skill: "Communication", students: 3, severity: "medium" },
    { skill: "Projects", students: 5, severity: "high" },
    { skill: "Internships", students: 6, severity: "high" },
    { skill: "Certifications", students: 4, severity: "medium" },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="pt-24 pb-12 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="mb-8">
            <Button variant="ghost" onClick={() => navigate("/teacher")} className="mb-4">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Upload
            </Button>
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div>
                <h1 className="text-4xl font-bold mb-2">
                  Batch <span className="text-gradient-gold">Analytics</span>
                </h1>
                <p className="text-muted-foreground">
                  Analysis results for: <span className="text-foreground">{fileName || "student_data.csv"}</span>
                </p>
              </div>
              <Button variant="gold">
                <Download className="h-4 w-4 mr-2" />
                Export Report
              </Button>
            </div>
          </div>

          {/* Stats Grid */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card variant="gold">
              <CardContent className="pt-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center">
                    <Users className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Total Students</p>
                    <p className="text-3xl font-bold">{totalStudents}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card variant="gold">
              <CardContent className="pt-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-success/20 flex items-center justify-center">
                    <CheckCircle2 className="h-6 w-6 text-success" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Likely Placed</p>
                    <p className="text-3xl font-bold text-success">{placedPercentage}%</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card variant="gold">
              <CardContent className="pt-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center">
                    <TrendingUp className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Avg. Probability</p>
                    <p className="text-3xl font-bold">{averageProbability}%</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card variant="gold">
              <CardContent className="pt-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-destructive/20 flex items-center justify-center">
                    <XCircle className="h-6 w-6 text-destructive" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Need Support</p>
                    <p className="text-3xl font-bold text-destructive">{totalStudents - placedStudents}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid lg:grid-cols-3 gap-8 mb-8">
            {/* Chart */}
            <Card variant="default" className="lg:col-span-2">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5 text-primary" />
                  Placement Distribution
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={chartData} layout="vertical">
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                      <XAxis type="number" stroke="hsl(var(--muted-foreground))" />
                      <YAxis dataKey="name" type="category" stroke="hsl(var(--muted-foreground))" />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: "hsl(var(--card))", 
                          border: "1px solid hsl(var(--border))",
                          borderRadius: "8px"
                        }}
                      />
                      <Bar dataKey="value" radius={[0, 4, 4, 0]}>
                        {chartData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Skill Gaps */}
            <Card variant="gold">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-warning" />
                  Skill Gap Insights
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {skillGaps.map((gap, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <span className="text-sm">{gap.skill}</span>
                      <div className="flex items-center gap-2">
                        <span className={`text-sm font-medium ${
                          gap.severity === "high" ? "text-destructive" : "text-warning"
                        }`}>
                          {gap.students} students
                        </span>
                        <div className={`w-2 h-2 rounded-full ${
                          gap.severity === "high" ? "bg-destructive" : "bg-warning"
                        }`} />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Student Table */}
          <Card variant="default">
            <CardHeader>
              <CardTitle>Student Analysis Details</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Student Name</TableHead>
                      <TableHead className="text-center">CGPA</TableHead>
                      <TableHead className="text-center">Status</TableHead>
                      <TableHead className="text-center">Probability</TableHead>
                      <TableHead>Top Suitable Role</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {mockStudents.map((student, index) => (
                      <TableRow key={index}>
                        <TableCell className="font-medium">{student.name}</TableCell>
                        <TableCell className="text-center">{student.cgpa.toFixed(1)}</TableCell>
                        <TableCell className="text-center">
                          <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${
                            student.status === "placed" 
                              ? "bg-success/20 text-success" 
                              : "bg-destructive/20 text-destructive"
                          }`}>
                            {student.status === "placed" ? (
                              <CheckCircle2 className="h-3 w-3" />
                            ) : (
                              <XCircle className="h-3 w-3" />
                            )}
                            {student.status === "placed" ? "Will Place" : "At Risk"}
                          </span>
                        </TableCell>
                        <TableCell className="text-center">
                          <span className={`font-semibold ${
                            student.probability >= 70 ? "text-success" : 
                            student.probability >= 50 ? "text-warning" : "text-destructive"
                          }`}>
                            {student.probability}%
                          </span>
                        </TableCell>
                        <TableCell>{student.topRole}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default TeacherDashboard;
