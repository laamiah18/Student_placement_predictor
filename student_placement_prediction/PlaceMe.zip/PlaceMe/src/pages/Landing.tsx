import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Header } from "@/components/Header";
import { 
  GraduationCap, 
  Users, 
  Target, 
  Sparkles, 
  ArrowRight,
  CheckCircle2,
  Building2,
  TrendingUp
} from "lucide-react";
import heroIllustration from "@/assets/hero-illustration.png";

const Landing = () => {
  const steps = [
    {
      icon: <Users className="h-8 w-8" />,
      title: "Enter Your Profile",
      description: "Input your academic scores, skills, and experience details",
    },
    {
      icon: <Sparkles className="h-8 w-8" />,
      title: "AI Analysis",
      description: "Our intelligent system analyzes your profile comprehensively",
    },
    {
      icon: <Target className="h-8 w-8" />,
      title: "Get Predictions",
      description: "Receive placement predictions and suitable job role suggestions",
    },
  ];

  const studentBenefits = [
    "Know your placement chances before campus drives",
    "Understand which job roles suit your profile",
    "Get personalized improvement recommendations",
    "Track your progress over time",
  ];

  const institutionBenefits = [
    "Analyze entire batches with bulk upload",
    "Identify students needing extra support",
    "Track placement readiness trends",
    "Make data-driven training decisions",
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 overflow-hidden">
        {/* Background effects */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
        </div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6 animate-fade-in">
              <Sparkles className="h-4 w-4 text-primary" />
              <span className="text-sm text-primary font-medium">AI-Powered Predictions</span>
            </div>
            
            <h1 className="text-5xl md:text-7xl font-bold mb-6 animate-fade-in" style={{ animationDelay: "0.1s" }}>
              <span className="text-foreground">Know Your</span>
              <br />
              <span className="text-gradient-gold">Placement Potential</span>
            </h1>
            
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-10 animate-fade-in" style={{ animationDelay: "0.2s" }}>
              PLACEME uses intelligent algorithms to predict your placement chances 
              and suggest the perfect job roles based on your unique profile.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in" style={{ animationDelay: "0.3s" }}>
              <Button variant="hero" size="xl" asChild>
                <Link to="/student">
                  <GraduationCap className="h-5 w-5 mr-2" />
                  Student Mode
                </Link>
              </Button>
              <Button variant="hero-outline" size="xl" asChild>
                <Link to="/teacher">
                  <Users className="h-5 w-5 mr-2" />
                  Teacher Mode
                </Link>
              </Button>
            </div>

            {/* Hero Image */}
            <div className="mt-16 animate-fade-in" style={{ animationDelay: "0.4s" }}>
              <div className="relative rounded-2xl overflow-hidden shadow-elevated border border-border/50">
                <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent z-10" />
                <img 
                  src={heroIllustration} 
                  alt="Students and analytics visualization" 
                  className="w-full h-auto"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-card/50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              How It <span className="text-gradient-gold">Works</span>
            </h2>
            <p className="text-muted-foreground max-w-xl mx-auto">
              Three simple steps to understand your career readiness
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {steps.map((step, index) => (
              <Card key={index} variant="interactive" className="p-8 text-center relative">
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-sm">
                  {index + 1}
                </div>
                <div className="w-16 h-16 mx-auto mb-6 rounded-2xl bg-primary/10 flex items-center justify-center text-primary">
                  {step.icon}
                </div>
                <h3 className="text-xl font-semibold mb-3">{step.title}</h3>
                <p className="text-muted-foreground">{step.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12">
            {/* For Students */}
            <Card variant="gold" className="p-8">
              <div className="flex items-center gap-4 mb-6">
                <div className="w-14 h-14 rounded-2xl bg-primary/20 flex items-center justify-center">
                  <GraduationCap className="h-7 w-7 text-primary" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold">For Students</h3>
                  <p className="text-muted-foreground">Empower your career journey</p>
                </div>
              </div>
              <ul className="space-y-4">
                {studentBenefits.map((benefit, index) => (
                  <li key={index} className="flex items-start gap-3">
                    <CheckCircle2 className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                    <span className="text-foreground">{benefit}</span>
                  </li>
                ))}
              </ul>
              <Button variant="gold" className="mt-8 w-full" asChild>
                <Link to="/student">
                  Get Started
                  <ArrowRight className="h-4 w-4 ml-2" />
                </Link>
              </Button>
            </Card>

            {/* For Institutions */}
            <Card variant="gold" className="p-8">
              <div className="flex items-center gap-4 mb-6">
                <div className="w-14 h-14 rounded-2xl bg-primary/20 flex items-center justify-center">
                  <Building2 className="h-7 w-7 text-primary" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold">For Institutions</h3>
                  <p className="text-muted-foreground">Transform placement outcomes</p>
                </div>
              </div>
              <ul className="space-y-4">
                {institutionBenefits.map((benefit, index) => (
                  <li key={index} className="flex items-start gap-3">
                    <CheckCircle2 className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                    <span className="text-foreground">{benefit}</span>
                  </li>
                ))}
              </ul>
              <Button variant="gold" className="mt-8 w-full" asChild>
                <Link to="/teacher">
                  Analyze Batch
                  <ArrowRight className="h-4 w-4 ml-2" />
                </Link>
              </Button>
            </Card>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-card/50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 max-w-4xl mx-auto text-center">
            {[
              { value: "95%", label: "Prediction Accuracy" },
              { value: "10K+", label: "Students Analyzed" },
              { value: "50+", label: "Institutions Trust Us" },
              { value: "8", label: "Job Role Categories" },
            ].map((stat, index) => (
              <div key={index} className="space-y-2">
                <div className="text-4xl md:text-5xl font-bold text-gradient-gold">{stat.value}</div>
                <div className="text-muted-foreground text-sm">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <Card variant="glass" className="max-w-4xl mx-auto p-12 text-center relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-primary/5" />
            <div className="relative z-10">
              <TrendingUp className="h-12 w-12 text-primary mx-auto mb-6" />
              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                Ready to Discover Your <span className="text-gradient-gold">Potential</span>?
              </h2>
              <p className="text-muted-foreground max-w-xl mx-auto mb-8">
                Join thousands of students who have already discovered their placement potential with PLACEME.
              </p>
              <Button variant="hero" size="xl" asChild>
                <Link to="/auth">
                  Get Started Now
                  <ArrowRight className="h-5 w-5 ml-2" />
                </Link>
              </Button>
            </div>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 border-t border-border">
        <div className="container mx-auto px-4 text-center text-muted-foreground text-sm">
          <p>© 2024 PLACEME. Intelligent Student Placement Prediction System.</p>
        </div>
      </footer>
    </div>
  );
};

export default Landing;
